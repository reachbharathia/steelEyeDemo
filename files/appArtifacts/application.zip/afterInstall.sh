#!/bin/bash

exec > >(tee /var/log/base_install/codedeploy_log/afterinstall.log|logger -t user-data -s 2>/dev/console) 2>&1
WorkingDirectory=/home/ec2-user/appartifacts
chmod u+rwx $WorkingDirectory/*.sh
dos2unix $WorkingDirectory/*.sh
$WorkingDirectory/installapp.sh

