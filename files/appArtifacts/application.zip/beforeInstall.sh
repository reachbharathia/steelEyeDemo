#!/bin/bash

if [ ! -d /var/log/base_install/codedeploy_log ]; then
  sudo mkdir -m 777 -p /var/log/base_install/codedeploy_log
fi


exec > >(tee /var/log/base_install/codedeploy_log/beforeinstall.log|logger -t user-data -s 2>/dev/console) 2>&1

yum -y install dos2unix
yum -y install wget

#switch to root user
echo `date '+%Y-%m-%d %H:%M:%S '` "Switch to root user"
sudo su
cd

#Download Go from Site..
echo `date '+%Y-%m-%d %H:%M:%S '` "Download Go from site.."
wget https://dl.google.com/go/go1.14.2.linux-amd64.tar.gz

#Untar the go file and set path
echo `date '+%Y-%m-%d %H:%M:%S '` "Untar the go file and set path.."
tar -C /usr/local -xzf go1.14.2.linux-amd64.tar.gz
export PATH=$PATH:/usr/local/go/bin
