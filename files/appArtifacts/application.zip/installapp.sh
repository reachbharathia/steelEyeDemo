#!/bin/bash

WorkingDirectory=/home/ec2-user/appartifacts

exec > >(tee /var/log/base_install/codedeploy_log/installapp.log|logger -t user-data -s 2>/dev/console) 2>&1

echo `date '+%Y-%m-%d %H:%M:%S '` "Copy server.go file to path"
cp $WorkingDirectory/application/server.go /usr/local/go/


echo `date '+%Y-%m-%d %H:%M:%S '` "Adding GO path to profile"
echo "export PATH=$PATH:/usr/local/go/bin" >> /etc/profile
source /etc/profile



#Run the server file in BackGround
echo `date '+%Y-%m-%d %H:%M:%S '` "Run the server file in BackGround"
go run /usr/local/go/server.go > /dev/null 2> /dev/null < /dev/null &

echo "Install App script completed.."










